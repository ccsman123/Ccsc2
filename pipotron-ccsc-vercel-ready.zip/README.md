# Pipotron CCSC

Un générateur de phrases bullshit institutionnelles prêt à être déployé sur Vercel.

### Démarrage local
```
npm install
npm run dev
```
